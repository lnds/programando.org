Respuesta al desafio: 
Desafío Julio – Agosto 2012: L-Systems


jquery llamado desde el CDN de google
turtle (supuesto del desafio) sacado de http://code.google.com/p/jquery-turtle/
sistemal.js  respuesta
test.html   ejemplos de prueba y 2 versiones de flor
mis dos flores "florecen" a partir de la 5 iteración, después solo crecen

Independiente que gane o pierda miserablemente, lo pasé muy bien programando CTM!
habría querido hacer algo más, pero debo descansar de vez en cuando...

gracias por la oportunidad de jugar


]-[.
